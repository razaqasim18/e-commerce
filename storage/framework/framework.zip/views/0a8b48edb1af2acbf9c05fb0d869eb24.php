<!DOCTYPE html>
<html lang="en">
<!-- auth-login.html  21 Nov 2019 03:49:32 GMT -->

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title> <?php echo $__env->yieldContent('title'); ?> </title>
    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bundles/bootstrap-social/bootstrap-social.css')); ?>">
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('bundles/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <link rel='shortcut icon' type='image/x-icon'
        href=' <?php echo e(SettingHelper::getSettingValueBySLug('site_favicon') ? asset('uploads/setting/' . SettingHelper::getSettingValueBySLug('site_favicon')) : asset('img/favicon.ico')); ?>' />

    
    <?php if ($__env->exists('include.style')) echo $__env->make('include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <div class="loader"></div>
    <div id="app">
        <section class="section">
            <?php echo $__env->yieldContent('content'); ?>
        </section>
    </div>
    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
    <!-- JS Libraies -->
    <!-- Page Specific JS File -->

    <script src="<?php echo e(asset('bundles/select2/dist/js/select2.full.min.js')); ?>"></script>
    <!-- Template JS File -->
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    <!-- Custom JS File -->
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>


<!-- auth-login.html  21 Nov 2019 03:49:32 GMT -->

</html>
<?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/layouts/auth.blade.php ENDPATH**/ ?>