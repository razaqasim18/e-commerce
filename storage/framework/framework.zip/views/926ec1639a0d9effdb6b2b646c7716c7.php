<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Checkout -->
    <section class="shop checkout section">
        <div class="container">
            <form class="form" method="post" action="<?php echo e(route('checkout.process')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-12">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-8 col-12">
                        <?php if(Auth::guard('web')->user() && Auth::guard('web')->user()->userdetail): ?>
                            <div class="checkout-form">
                                <h2>Make Your Checkout Here</h2>
                                <p>Where You want us to deliver </p>
                                <!-- Form -->
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-12">
                                        <div class="form-group">
                                            <label>First Name<span>*</span></label>
                                            <input type="text" name="name" placeholder="" required="required"
                                                value="<?php echo e(Auth::guard('web')->user()->name); ?>">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Email Address<span>*</span></label>
                                            <input type="email" name="email" placeholder="" required="required"
                                                value="<?php echo e(Auth::guard('web')->user()->email); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Phone Number<span>*</span></label>
                                            <input type="number" name="phone" placeholder="" required="required"
                                                value="<?php echo e(Auth::guard('web')->user()->phone); ?>">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>City<span>*</span></label>
                                            <select class="city" name="city" required>
                                                <option value="">Select Option</option>
                                                <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($row->id); ?>"
                                                        <?php if(Auth::guard('web')->user()->userdetail->city_id == $row->id): ?> selected <?php endif; ?>>
                                                        <?php echo e($row->city); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Street<span>*</span></label>
                                            <input type="text" name="street" placeholder="" required="required"
                                                value="<?php echo e(Auth::guard('web')->user()->userdetail->street); ?>">
                                            <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Address<span>*</span></label>
                                            <input type="text" name="address" placeholder="" required="required"
                                                value="<?php echo e(Auth::guard('web')->user()->userdetail->address); ?>">
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Shipping Address</label>
                                            <input type="text" name="shipping_address" placeholder="" required="required"
                                                value="<?php echo e(Auth::guard('web')->user()->userdetail->shipping_address); ?>">
                                            <?php $__errorArgs = ['shipping_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-12">
                                        <div class="form-group">
                                            <label>Other Information</label>
                                            <input type="text" name="other" placeholder="">
                                            <?php $__errorArgs = ['other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                </div>

                                <!--/ End Form -->
                            </div>
                        <?php else: ?>
                            <div class="checkout-form">
                                <p>Please add your shipping details for checkout
                                </p>
                                <a class="text-primary" href="<?php echo e(route('profile.load')); ?>">Profile Information</a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-4 col-12">
                        <div class="order-details">
                            <!-- Order Widget -->
                            <div class="single-widget">
                                <h2>CART TOTALS</h2>
                                <div class="content">
                                    <?php
                                        $attribute = $weight = $subtotal = 0;
                                        foreach (\Cart::getContent() as $item) {
                                            $attribute = $attribute + $item->attributes->product_points;
                                            $weight = $weight + $item->attributes->product_weight;
                                            $subtotal = $subtotal + $item->getPriceSum();
                                        }
                                        $shippingcharges = $weight * SettingHelper::getSettingValueBySLug('shipping_charges');
                                        $totalpay = $subtotal + $shippingcharges;
                                    ?>
                                    <ul>
                                        <li>
                                            Point<span><?php echo e($attribute); ?></span>
                                            <input type="hidden" name="subpoint" id="subpoint"
                                                value="<?php echo e($attribute); ?>" />
                                        </li>
                                        <li>
                                            Weight <span><?php echo e($weight); ?> KG</span>
                                            <input type="hidden" name="totalweight" id="totalweight"
                                                value="<?php echo e($weight); ?>" />
                                        </li>
                                        <li>
                                            Sub Total<span>PKR <?php echo e($subtotal); ?></span>
                                            <input type="hidden" name="subtotal" id="subtotal"
                                                value="<?php echo e($subtotal); ?>" />
                                        </li>
                                        <li>
                                            (+) Shipping
                                            <span>PKR <?php echo e($shippingcharges); ?></span>
                                            <input type="hidden" name="shippingcharges" id="totalshippingcharges"
                                                value="<?php echo e($shippingcharges); ?>" />
                                        </li>
                                        <li class="last">
                                            Total<span>PKR <?php echo e($totalpay); ?></span>
                                            <input type="hidden" name="totalpay" id="totalpay"
                                                value="<?php echo e($totalpay); ?>" />
                                        </li>
                                    </ul>
                                </div>

                            </div>
                            <!--/ End Order Widget -->
                            <!-- Order Widget -->
                            <div class="single-widget">
                                <h2>Payments</h2>
                                <div class="content">
                                    <div style="display:block;padding: 10px 27px;">
                                        <input name="payment_by" id="payment_cash" type="radio" value="0"
                                            checked>
                                        <label for="payment_cash">
                                            By Cash
                                        </label><br />
                                        <div class="row">
                                            <div class="col-md-6 text-left">
                                                <input name="payment_by" id="payment_wallet" type="radio"
                                                    value="1">
                                                <label for="payment_wallet">
                                                    By Wallet
                                                </label>
                                            </div>
                                            <?php if(Auth::guard('web')->user() && Auth::guard('web')->user()->userdetail): ?>
                                                <div class="col-md-6 text-right">
                                                    <label><b>Balance:</b> <?php echo CustomHelper::getUserWalletAmountByid(Auth::user()->id); ?> </label>
                                                </div>
                                                <input type="hidden" name="balance" value="<?php echo CustomHelper::getUserWalletAmountByid(Auth::user()->id); ?>" />
                                                <?php $__errorArgs = ['balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="col-md-12 text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <?php endif; ?>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!--/ End Order Widget -->

                            <!-- Button Widget -->
                            <div class="single-widget get-button">
                                <div class="content">
                                    <div class="button">
                                        <button type="submit" class="btn"
                                            <?php if(!(Auth::guard('web')->user() && Auth::guard('web')->user()->userdetail && \Cart::getContent()->count())): ?> disabled <?php endif; ?>>proceed to checkout</button>
                                    </div>
                                </div>
                            </div>
                            <!--/ End Button Widget -->
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!--/ End Checkout -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/checkout.blade.php ENDPATH**/ ?>