<?php $__env->startSection('title'); ?>
    User || Dasboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Team View of : <?php echo e('ABF-' . $user->id); ?> (<?php echo e($user->name); ?>)</h4>
                                <div class="card-header-action"> </div>
                            </div>
                            <div class="card-body">
                                <div class="activities">
                                    <?php $__empty_1 = true; $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="activity">
                                            <div class="activity-icon bg-primary text-white">
                                                <?php if(!empty($row->image)): ?>
                                                    <img alt="image" src="<?php echo e(asset('img/users/user-2.png')); ?>"
                                                        class="rounded-circle" width="35" data-toggle="tooltip"
                                                        title="" data-original-title="<?php echo e($row->name); ?>">
                                                <?php else: ?>
                                                    <i class="fas fa-user"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="activity-detail">
                                                <div class="d-flex">
                                                    <p>
                                                        <?php echo e($row->ABFid); ?>

                                                    </p> &nbsp;
                                                    <p><strong>: Points 0</strong></p>
                                                </div>
                                                <a
                                                    href="<?php echo e(route('team.list', ['id' => \Crypt::encryptString($row->id)])); ?>">
                                                    <?php echo e($row->name); ?>

                                                </a>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="activity">
                                            <div class="activity-icon bg-primary text-white">
                                                <i class="fas fa-user"></i>
                                            </div>
                                            <div class="activity-detail">
                                                <p>
                                                    No User Found
                                                </p>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/user/team/index.blade.php ENDPATH**/ ?>