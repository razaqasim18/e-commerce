<style>
    .header.shop .header-inner {
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    .footer {
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    .header.sticky .header-inner .nav li a {
        color: #fff;
    }

    .header.shop .all-category {
        color: #fff;
        background: transparent;
        position: relative;
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .shop-newsletter .newsletter-inner .btn {
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    .shop-newsletter .newsletter-inner .btn:hover {
        color: #fff;
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .midium-banner .single-banner a {
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .midium-banner .single-banner a:hover {
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    .hero-slider .hero-text .btn {
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .hero-slider .hero-text .btn:hover {
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    .header.shop .top-left .list-main li i {
        color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .header.shop .list-main li i {
        color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .header.shop .right-bar .sinlge-bar .single-icon .total-count {
        background: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .single-product .product-content h3 a:hover {
        color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .section-title h2::before {
        background: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .shopping-summery thead {
        background: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    #scrollUp i {
        background: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    #scrollUp i:hover {
        background: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .btn {
        background: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    .btn:hover {
        background: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .quickview-content .add-to-cart .btn {
        background: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    .header.shop .nav li.active a {
        color: #fff;
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .header.shop .nav li:hover a {
        color: #fff;
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .header.shop .nav li .dropdown li:hover a {
        color: #fff;
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .footer .links ul li a:hover {
        padding-left: 10px;
        color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .footer .about .call a {
        font-size: 20px;
        font-weight: 600;
        color: <?php echo e(SettingHelper::getSettingValueBySLug('site_secondary_color')); ?>;
    }

    .page-item.active .page-link {
        z-index: 2;
        color: #fff;
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
        border-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }

    .page-link:hover {
        color: #fff;
        background-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
        border-color: <?php echo e(SettingHelper::getSettingValueBySLug('site_primary_color')); ?>;
    }
</style>
<?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/include/eshop_style.blade.php ENDPATH**/ ?>