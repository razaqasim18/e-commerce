<?php $__env->startSection('title'); ?>
    Admin || Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('bundles/dropzonejs/dropzone.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Add Product</h4>
                                <div class="card-header-action">
                                    <a href="<?php echo e(route('admin.product.list')); ?>" class="btn btn-primary">
                                        Product List</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <form class="form-horizontal form-bordered" id="form" method="POST"
                                    enctype="multipart/form-data" action="<?php echo e(route('admin.product.insert')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                    <?php endif; ?>
                                    <?php if(session('error')): ?>
                                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                                    <?php endif; ?>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="brand_id">Brand</label>
                                            <span class="text-danger">*</span>
                                            <select class="form-control" name="brand_id" id="brand_id">
                                                <option value="">Select</option>
                                                <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($row->id); ?>"
                                                        <?php if(old('brand_id') == $row->id): ?> selected <?php endif; ?>>
                                                        <?php echo e($row->brand); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="category_id">Category</label>
                                            <span class="text-danger">*</span>
                                            <select class="form-control" name="category_id" id="category_id">
                                                <option value="">Select</option>
                                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($row->id); ?>"
                                                        <?php if(old('category_id') == $row->id): ?> selected <?php endif; ?>>
                                                        <?php echo e($row->category); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="product">Product</label>
                                            <span class="text-danger">*</span>
                                            <input type="text" class="form-control" name="product" id="product"
                                                value="<?php echo e(old('product')); ?>" required>
                                            <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="points">Points</label>
                                            <span class="text-danger">*</span>
                                            <input type="number" class="form-control" name="points" id="points"
                                                value="<?php echo e(old('points')); ?>" required>
                                            <?php $__errorArgs = ['points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="price">Price</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="number" min="0" class="form-control" name="price"
                                                    id="price" step=".01" value="<?php echo e(old('price')); ?>"
                                                    required="">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        PKR
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="purchase_price">Purchase Price</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="number" min="0" class="form-control"
                                                    name="purchase_price" id="purchase_price" step=".01"
                                                    value="<?php echo e(old('purchase_price')); ?>" required="">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        PKR
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="stock">Stock</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="number" min="0" class="form-control" name="stock"
                                                    id="stock" value="<?php echo e(old('stock')); ?>" required="">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        Unit
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <div class="form-group mt-2 mb-0">
                                                <div class="form-row">
                                                    <div class="col-md-12">
                                                        <div class="custom-control custom-checkbox">
                                                            <input class="custom-control-input" type="checkbox"
                                                                id="is_stock" name="is_stock" value="1"
                                                                <?php echo e(old('is_stock') == '1' ? 'checked' : ''); ?>>
                                                            <label class="custom-control-label" for="is_stock">
                                                                In Stock
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="discount">Discount</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="number" min="0" class="form-control"
                                                    name="discount" id="discount" value="<?php echo e(old('discount')); ?>"
                                                    required="">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        %
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <div class="form-group mt-2 mb-0">
                                                <div class="form-row">
                                                    <div class="col-md-12">
                                                        <div class="custom-control custom-checkbox">
                                                            <input class="custom-control-input" type="checkbox"
                                                                id="is_discount" name="is_discount" value="1"
                                                                <?php echo e(old('is_discount') == '1' ? 'checked' : ''); ?>>
                                                            <label class="custom-control-label" for="is_discount">
                                                                In Stock
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="weight">Weight</label>
                                            <span class="text-danger">*</span>
                                            <div class="input-group">
                                                <input type="number" min="1" class="form-control" name="weight"
                                                    id="weight" value="<?php echo e(old('weight')); ?>" required="">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        Kg
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="description">Description</label>
                                            <input type="text" class="form-control" name="description"
                                                id="description" value="<?php echo e(old('description')); ?>" required="">
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="form-row mb-3">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Product Feature Image</label>
                                                <input name="image" type="file" class="form-control"
                                                    accept="image/png, image/gif, image/jpeg, image/jpg" />
                                            </div>
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Product Image</label>
                                                <input id="file" name="file[]" type="file" class="form-control"
                                                    accept="image/png, image/gif, image/jpeg, image/jpg" multiple>
                                            </div>
                                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label>Active</label>
                                            <div class="form-row mt-2">
                                                <div class="col-md-12">
                                                    <div class="custom-control custom-checkbox">
                                                        <input class="custom-control-input" type="checkbox"
                                                            id="is_active" name="is_active" value="1"
                                                            <?php echo e(old('is_active') == '1' ? 'checked' : ''); ?>>
                                                        <label class="custom-control-label" for="is_active">
                                                            Is Active
                                                        </label>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Is Other</label>
                                            <div class="form-row mt-2">
                                                <div class="col-md-12">
                                                    <div class="custom-control custom-checkbox">
                                                        <input class="custom-control-input" type="checkbox"
                                                            id="is_other" name="is_other" value="1"
                                                            <?php echo e(old('is_other') == '1' ? 'checked' : ''); ?>>
                                                        <label class="custom-control-label" for="is_other">
                                                            Is Other
                                                        </label>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Is Feature</label>
                                            <div class="form-row mt-2">
                                                <div class="col-md-12">
                                                    <div class="custom-control custom-checkbox">
                                                        <input class="custom-control-input" type="checkbox"
                                                            id="is_feature" name="is_feature" value="1"
                                                            <?php echo e(old('is_feature') == '1' ? 'checked' : ''); ?>>
                                                        <label class="custom-control-label" for="is_feature">
                                                            Is Feature
                                                        </label>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="card-footer text-right">
                                        <button class="btn btn-secondary" type="reset">Reset</button>
                                        <button class="btn btn-primary mr-1" id="dropzoneSubmit">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('bundles/dropzonejs/min/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/multiple-upload.js')); ?>"></script>
    <script>
        // const input = document.querySelector('#file');
        // // Listen for files selection
        // input.addEventListener('change', (e) => {
        //     // Retrieve all files
        //     const files = input.files;
        //     // Check files count
        //     if (files.length > 3) {
        //         swal('Error', 'Only 3 files are allowed to upload.', 'error');
        //         $("#file").val(null);
        //         return false;
        //     }
        // });
        // Initialize Dropzone instance with custom options
        // if (window.Dropzone) {
        //     Dropzone.autoDiscover = false;
        // }
        // Disable auto-discover of dropzone elements

        // var myDropzone = new Dropzone("#mydropzone", {
        //     url: "<?php echo e(route('admin.product.insert')); ?>",
        //     paramName: "file",
        //     maxFilesize: 2, // Max file size in MB
        //     maxFiles: 10, // Max number of files
        //     parallelUploads: 1, // Number of files to upload at once
        //     acceptedFiles: ".png, .jpg, .jpeg, .gif", // Allowed file types
        //     addRemoveLinks: true,
        //     uploadMultiple: true,
        //     autoProcessQueue: false,
        // });

        // Add event listener for sending event to include additional form data
        // myDropzone.on("sending", function(file, xhr, formData) {
        //     formData.append("_token", "<?php echo e(csrf_token()); ?>");
        //     formData.append("brand_id", $("#brand_id").val());
        //     formData.append("category_id", $("#category_id").val());
        //     formData.append("product", $("#product").val());
        //     formData.append("points", $("#points").val());
        //     formData.append("price", $("#price").val());
        //     formData.append("purchase_price", $("#purchase_price").val());
        //     formData.append("is_active", $("#is_active").val());
        //     formData.append("is_other", $("#is_other").val());
        //     formData.append("is_stock", $("#product").val());
        //     formData.append("is_feature", $("#is_feature").val());
        //     formData.append("description", $("#description").val());
        // });
        // $('#imgsubbutt').click(function() {
        //     myDropzone.processQueue();
        // });

        // Dropzone.options.myDropzone = {
        //     // The setting up of the dropzone
        //     init: function() {
        //         var myDropzone = this;

        //         // First change the button to actually tell Dropzone to process the queue.
        //         $("#dropzoneSubmit").on("click", function(e) {
        //             // Make sure that the form isn't actually being sent.
        //             e.preventDefault();
        //             e.stopPropagation();

        //             console.log(myDropzone.files);
        //             if (myDropzone.files != "") {
        //                 console.log(myDropzone.processQueue());
        //                 myDropzone.processQueue();
        //             } else {
        //                 // $("#form").submit();
        //             }

        //         });

        //         // on add file
        //         this.on("addedfile", function(file) {
        //             // console.log(file);
        //         });
        //         // on error
        //         this.on("error", function(file, response) {
        //             // console.log(response);
        //         });
        //         // on start
        //         this.on("sendingmultiple", function(file) {
        //             // console.log(file);
        //         });
        //         // on success
        //         this.on("successmultiple", function(file) {
        //             // submit form
        //             console.log("successmult");
        //             // $("#form").submit();
        //         });
        //     }
        // };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/admin/product/add.blade.php ENDPATH**/ ?>