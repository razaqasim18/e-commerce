<?php echo e($slot); ?>

<?php /**PATH C:\xamp\htdocs\laravel\e-commerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>