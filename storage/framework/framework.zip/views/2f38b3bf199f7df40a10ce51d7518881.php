<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="small-banner section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <!-- Product Slider -->
                    <div class="product-gallery">
                        <div class="quickview-slider-active">
                            <?php if($product->image): ?>
                                <div class="single-slider">
                                    <img src="<?php echo e(asset('uploads/product') . '/' . $product->image); ?>"
                                        alt="<?php echo e($product->product); ?>">
                                </div>
                            <?php endif; ?>
                            <?php if($product->getMedia('images')): ?>
                                <?php $__currentLoopData = $product->getMedia('images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-slider">
                                        <img src="<?php echo e($image->getUrl()); ?>" alt="<?php echo e($image->name); ?>">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if(!($product->image && $product->getMedia('images'))): ?>
                                <div class="single-slider">
                                    <img src="<?php echo e(asset('img/products/product-1.png')); ?>" alt="<?php echo e($product->image); ?>">
                                </div>
                                <div class="single-slider">
                                    <img src="<?php echo e(asset('img/products/product-1.png')); ?>" alt="<?php echo e($product->image); ?>">
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- End Product slider -->
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="quickview-content">
                        <h2><?php echo e($product->product); ?></h2>
                        
                        <h3>
                            <a class="midium-banner single-banner a">PRICE</a>: <?php echo e('PKR ' . $product->price); ?>

                        </h3>
                        <?php if(SettingHelper::getSettingValueBySLug('gst_charges')): ?>
                            <h3>
                                <a class="midium-banner single-banner a">PRICE With GST</a>:
                                <?php echo e('PKR ' . ceil($product->price + $product->price / SettingHelper::getSettingValueBySLug('gst_charges'))); ?>

                            </h3>
                        <?php endif; ?>

                        <div class="quickview-peragraph">
                            <p><?php echo e($product->description); ?></p>
                        </div>
                        <br />
                        <div class="quantity">
                            <!-- Input Order -->
                            <div class="input-group">
                                <div class="button minus">
                                    <button type="button" class="btn btn-primary btn-number" disabled="disabled"
                                        data-type="minus" data-field="quant[1]">
                                        <i class="ti-minus"></i>
                                    </button>
                                </div>
                                <input type="text" id="quantity" data-productid="<?php echo e($product->id); ?>" name="quant[1]"
                                    class="input-number" data-min="1" data-max="1000" value="1">
                                <div class="button plus">
                                    <button type="button" class="btn btn-primary btn-number" data-type="plus"
                                        data-field="quant[1]">
                                        <i class="ti-plus"></i>
                                    </button>
                                </div>
                            </div>
                            <!--/ End Input Order -->
                        </div>
                        <div class="add-to-cart">
                            <a href="javascript:void(0)" id="addToCart" data-productid="<?php echo e($product->id); ?>"
                                class="btn">Add to cart</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/product_detail.blade.php ENDPATH**/ ?>