<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name='copyright' content=''>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title Tag  -->
    <title><?php echo e(SettingHelper::getSettingValueBySLug('site_name')); ?></title>
    <!-- Favicon -->
    <link rel='shortcut icon' type='image/x-icon'
        href=' <?php echo e(SettingHelper::getSettingValueBySLug('site_favicon') ? asset('uploads/setting/' . SettingHelper::getSettingValueBySLug('site_favicon')) : asset('img/favicon.ico')); ?>' />
    <!-- Web Font -->
    <link
        href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap"
        rel="stylesheet">

    <!-- StyleSheet -->

    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/bootstrap.css')); ?>">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/magnific-popup.min.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/font-awesome.css')); ?>">
    <!-- Fancybox -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/jquery.fancybox.min.css')); ?>">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/themify-icons.css')); ?>">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/niceselect.css')); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/animate.css')); ?>">
    <!-- Flex Slider CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/flex-slider.min.css')); ?>">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/owl-carousel.css')); ?>">
    <!-- Slicknav -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/slicknav.min.css')); ?>">

    <!-- Eshop StyleSheet -->
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('eshop/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('eshop/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bundles/izitoast/css/iziToast.min.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>

    <?php if ($__env->exists('include.eshop_style')) echo $__env->make('include.eshop_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="js">

    <!-- Preloader -->
    <div class="preloader">
        <div class="preloader-inner">
            <div class="preloader-icon">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- End Preloader -->


    <!-- Header -->
    <header class="header shop">
        <!-- Topbar -->
        <div class="topbar">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-12">
                        <!-- Top Left -->
                        <div class="top-left">
                            <ul class="list-main">
                                <li><i class="ti-headphone-alt"></i> +060 (800) 801-582</li>
                                <li><i class="ti-email"></i> support@shophub.com</li>
                            </ul>
                        </div>
                        <!--/ End Top Left -->
                    </div>
                    <div class="col-lg-8 col-md-12 col-12">
                        <!-- Top Right -->
                        <div class="right-content">
                            <ul class="list-main">
                                
                                
                                <?php if(Auth::guard('web')->user()): ?>
                                    <li><i class="ti-user"></i> <a href="<?php echo e(route('dashboard')); ?>">My account</a></li>
                                <?php else: ?>
                                    <li><i class="ti-pin"></i><a href="<?php echo e(route('request.epin.load')); ?>">Buy
                                            Epin</a></li>
                                    <li><i class="ti-power-off"></i><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <!-- End Top Right -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Topbar -->
        <div class="middle-inner">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-12">
                        <!-- Logo -->
                        <div class="logo">
                            <a href="<?php echo e(route('welcome')); ?>"><img
                                    src="<?php echo e(SettingHelper::getSettingValueBySLug('site_logo') ? asset('uploads/setting/' . SettingHelper::getSettingValueBySLug('site_logo')) : asset('img/logo.png')); ?>"
                                    alt="logo"></a>
                        </div>
                        <!--/ End Logo -->

                        <div class="mobile-nav"></div>
                    </div>
                    <div class="col-lg-8 col-md-7 col-12">

                    </div>
                    <div class="col-lg-2 col-md-3 col-12">
                        <div class="right-bar">
                            <div class="sinlge-bar">
                                <a href="#" class="single-icon"><i class="fa fa-user-circle-o"
                                        aria-hidden="true"></i></a>
                            </div>
                            <div class="sinlge-bar shopping">
                                <a href="#" class="single-icon">
                                    <i class="ti-bag"></i>
                                    <span class="total-count spanItemCount"></span>
                                </a>
                                <!-- Shopping Item -->
                                <div class="shopping-item">
                                    <div class="dropdown-cart-header">
                                        <span> <span class="spanItemCount"></span> Items</span>
                                        <a href="<?php echo e(route('cart.index')); ?>">View Cart</a>
                                    </div>
                                    <ul class="shopping-list" id="shoppingList">

                                    </ul>
                                    <div class="bottom">
                                        <div class="total">
                                            <span>Total</span>
                                            <span class="total-amount" id="totalAmount"></span>
                                        </div>
                                        
                                    </div>
                                </div>
                                <!--/ End Shopping Item -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header Inner -->
        <div class="header-inner">
            <div class="container">
                <div class="cat-nav-head">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="all-category">
                                <h3 class="cat-heading"><?php echo e(SettingHelper::getSettingValueBySLug('site_name')); ?></h3>
                            </div>
                        </div>
                        <div class="col-lg-9 col-12">
                            <div class="menu-area">
                                <!-- Main Menu -->
                                <nav class="navbar navbar-expand-lg">
                                    <div class="navbar-collapse">
                                        <div class="nav-inner">
                                            <ul class="nav main-menu menu navbar-nav">
                                                <li class="active"><a href="<?php echo e(route('welcome')); ?>">Home</a></li>
                                                
                                                <li>
                                                    <a href="#">Shop
                                                        
                                                    </a>
                                                    <ul class="dropdown">
                                                        <li><a href="<?php echo e(route('shop')); ?>">Shop</a></li>
                                                        <li><a href="<?php echo e(route('cart.index')); ?>">Cart</a></li>
                                                        <li><a href="<?php echo e(route('checkout')); ?>">Checkout</a></li>
                                                    </ul>
                                                </li>
                                                
                                                <li><a href="contact.html">Contact Us</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </nav>
                                <!--/ End Main Menu -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Header Inner -->
    </header>
    <!--/ End Header -->

    <?php echo $__env->yieldContent('content'); ?>

    <!-- Start Footer Area -->
    <footer class="footer">
        <!-- Footer Top -->
        <div class="footer-top section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-6 col-12">
                        <!-- Single Widget -->
                        <div class="single-footer about">
                            <div class="logo">
                                <a href="<?php echo e(route('welcome')); ?>"><img
                                        src="<?php echo e(SettingHelper::getSettingValueBySLug('site_logo') ? asset('uploads/setting/' . SettingHelper::getSettingValueBySLug('site_logo')) : asset('img/logo.png')); ?>"
                                        alt="#"></a>
                            </div>
                            <p class="text">Praesent dapibus, neque id cursus ucibus, tortor neque egestas augue,
                                magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan
                                porttitor, facilisis luctus, metus.</p>
                            <p class="call">Got Question? Call us 24/7<span><a href="tel:123456789">+0123 456
                                        789</a></span></p>
                        </div>
                        <!-- End Single Widget -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-12">
                        <!-- Single Widget -->
                        <div class="single-footer links">
                            <h4>Information</h4>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Faq</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">Help</a></li>
                            </ul>
                        </div>
                        <!-- End Single Widget -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-12">
                        <!-- Single Widget -->
                        <div class="single-footer links">
                            <h4>Customer Service</h4>
                            <ul>
                                <li><a href="#">Payment Methods</a></li>
                                <li><a href="#">Money-back</a></li>
                                <li><a href="#">Returns</a></li>
                                <li><a href="#">Shipping</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                            </ul>
                        </div>
                        <!-- End Single Widget -->
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <!-- Single Widget -->
                        <div class="single-footer social">
                            <h4>Get In Tuch</h4>
                            <!-- Single Widget -->
                            <div class="contact">
                                <ul>
                                    <li>NO. 342 - London Oxford Street.</li>
                                    <li>012 United Kingdom.</li>
                                    <li>info@eshop.com</li>
                                    <li>+032 3456 7890</li>
                                </ul>
                            </div>
                            <!-- End Single Widget -->
                            <ul>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter"></i></a></li>
                                <li><a href="#"><i class="ti-flickr"></i></a></li>
                                <li><a href="#"><i class="ti-instagram"></i></a></li>
                            </ul>
                        </div>
                        <!-- End Single Widget -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Top -->
        <div class="copyright">
            <div class="container">
                <div class="inner">
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <div class="left">
                                <p>Copyright © 2020 <a href="https://trylotech.com/" target="_blank">Trylo Tech</a> -
                                    All Rights Reserved.</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-12">
                            <div class="right">
                                <img src="<?php echo e(asset('eshop/images/payments.png')); ?>" alt="#">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- /End Footer Area -->

    <!-- Jquery -->
    <script src="<?php echo e(asset('eshop/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('eshop/js/jquery-migrate-3.0.0.js')); ?>"></script>
    <script src="<?php echo e(asset('eshop/js/jquery-ui.min.js')); ?>"></script>
    <!-- Popper JS -->
    <script src="<?php echo e(asset('eshop/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('eshop/js/bootstrap.min.js')); ?>"></script>
    <!-- Color JS -->
    
    <!-- Slicknav JS -->
    <script src="<?php echo e(asset('eshop/js/slicknav.min.js')); ?>"></script>
    <!-- Owl Carousel JS -->
    <script src="<?php echo e(asset('eshop/js/owl-carousel.js')); ?>"></script>
    <!-- Magnific Popup JS -->
    <script src="<?php echo e(asset('eshop/js/magnific-popup.js')); ?>"></script>
    <!-- Waypoints JS -->
    <script src="<?php echo e(asset('eshop/js/waypoints.min.js')); ?>"></script>
    <!-- Countdown JS -->
    <script src="<?php echo e(asset('eshop/js/finalcountdown.min.js')); ?>"></script>
    <!-- Nice Select JS -->
    <script src="<?php echo e(asset('eshop/js/nicesellect.js')); ?>"></script>
    <!-- Flex Slider JS -->
    <script src="<?php echo e(asset('eshop/js/flex-slider.js')); ?>"></script>
    <!-- ScrollUp JS -->
    <script src="<?php echo e(asset('eshop/js/scrollup.js')); ?>"></script>
    <!-- Onepage Nav JS -->
    <script src="<?php echo e(asset('eshop/js/onepage-nav.min.js')); ?>"></script>
    <!-- Easing JS -->
    <script src="<?php echo e(asset('eshop/js/easing.js')); ?>"></script>
    <!-- Active JS -->
    <script src="<?php echo e(asset('eshop/js/active.js')); ?>"></script>
    <script src="<?php echo e(asset('bundles/izitoast/js/iziToast.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script>
        $('document').ready(function() {
            getItemList();

            $('a#addToCart').on('click', function() {
                let productid = $(this).data('productid');
                let productquantity = 1;
                if ($("input#quantity").val()) {
                    productquantity = $("input#quantity").val();
                }
                $.ajax({
                    url: '<?php echo e(route('cart.insert')); ?>',
                    method: "POST",
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        productid: productid,
                        quantity: productquantity
                    },
                    beforeSend: function() {
                        $(".preloader").show();
                    },
                    complete: function() {
                        $(".preloader").hide();
                    },
                    success: function(response) {
                        if (response.type) {
                            iziToast.success({
                                title: 'Success',
                                message: response.msg,
                                position: 'topRight'
                            });
                            getItemList();
                        } else {
                            iziToast.error({
                                title: 'Error!',
                                message: response.msg,
                                position: 'topRight'
                            });
                        }
                    }
                });
            });

            $('body').on("click", "a.removeProduct", function() {
                let productid = $(this).data('productid');
                $.ajax({
                    url: '<?php echo e(route('cart.delete')); ?>',
                    method: "POST",
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        productid: productid,
                    },
                    beforeSend: function() {
                        $(".preloader").show();
                    },
                    complete: function() {
                        $(".preloader").hide();
                    },
                    success: function(response) {
                        if (response.type) {
                            iziToast.success({
                                title: 'Success',
                                message: response.msg,
                                position: 'topRight'
                            });
                            if (window.location.toString().includes("cart")) {
                                location.reload();
                            } else {
                                getItemList();
                            }
                        } else {
                            iziToast.error({
                                title: 'Error!',
                                message: response.msg,
                                position: 'topRight'
                            });
                        }
                    }
                });
            });


        });

        function getItemList() {
            $.ajax({
                url: '<?php echo e(route('cart.list')); ?>',
                method: "GET",
                // data: {
                //     _token: '<?php echo e(csrf_token()); ?>',
                //     productid: productid,
                // },
                beforeSend: function() {
                    $(".preloader").show();
                },
                complete: function() {
                    $(".preloader").hide();
                },
                success: function(response) {
                    var item = '';
                    if (Object.keys(response.list).length) {
                        Object.keys(response.list).forEach(function(key) {
                            const element = response.list[key];
                            element.attributes['product_image'];
                            var image = element.attributes.product_image ?
                                "<?php echo e(asset('uploads/product')); ?>" + '/' + element.attributes
                                .product_image : "<?php echo e(asset('img/products/product-1.png')); ?>";
                            // console.log(key, response.list[key]);
                            item +=
                                '<li><a href="javascript:void(0)" class="remove removeProduct" data-productid="' +
                                element.id +
                                '" title="Remove this item"> <i class="fa fa-remove"> </i></a>';
                            item +=
                                '<a class="cart-img" href="javascript:void(0)"><img src="' + image +
                                '" alt="#"></a>';
                            item += '<h4><a href="javascript:void(0)">' + element.name + '</a></h4>';
                            item +=
                                '<p class = "quantity">' + element.quantity +
                                'x - <span class="amount"> PKR ' + element.price + '</span></p></li>';
                            // }
                        });
                    }
                    $("ul#shoppingList").html(item);
                    $("span.spanItemCount").text(response.count ? response.count : 0);
                    $("#totalAmount").text("PKR " + response.subtotal);
                }
            });
        }
    </script>
</body>

</html>
<?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/layouts/eshop.blade.php ENDPATH**/ ?>