<?php $__env->startSection('title'); ?>
    User || Dasboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12">

                        <div class="card">
                            <div class="card-header">
                                <h4>Request A WithDraw</h4>
                            </div>
                            <div class="card-body">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 pr-0 pt-3">
                                        <table class="table table-striped" style="border: 2px solid #F5F5F5">
                                            <thead>
                                                <tr>
                                                    <th scope="col" colspan="2">Your Payment Account Information
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $useraccount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <th>Bank</th>
                                                        <td class="text-right"><?php echo e($row->name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Account Holder Name</th>
                                                        <td class="text-right"><?php echo e($row->account_holder_name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Account Number</th>
                                                        <td class="text-right"><?php echo e($row->account_number); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Account IBAN</th>
                                                        <td class="text-right"><?php echo e($row->account_iban); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td>Your Payment Account Detail Is Missing . Add Your Account Detail
                                                            first To Make WithDraw Request
                                                            <a href="<?php echo e(route('payment.information.load')); ?>">Payment
                                                                Account</a>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 pr-0 pt-3">
                                        <form method="POST" action="<?php echo e(route('withdraw.insert')); ?>"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group row mb-1">
                                                <h4 class="col-6">Balance in Wallet:</h4>
                                                <h2 class="col-6 text-right text-primary">
                                                    <?php echo CustomHelper::getUserWalletAmountByid(Auth::user()->id); ?>

                                                    </h5>
                                            </div>
                                            <div class="form-group">
                                                <label for="amount">Amount Deposit</label>
                                                <div class="input-group">
                                                    <input type="number" min="0" step=".01"
                                                        class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="amount" value="<?php echo e(old('amount')); ?>" required>
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            PKR
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span><br />
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <span class="col-sm-12 pl-0 pr-0 mt-2">
                                                    <strong>Amount: (Must be greater then 1000 Rs.)</strong>
                                                </span><br />

                                            </div>
                                            <div class="form-group mt-2 mb-2">
                                                <button type="submit" class="btn btn-primary btn-lg btn-block"
                                                    tabindex="4">
                                                    Submit
                                                </button>
                                            </div>
                                            <span class="col-sm-12 pl-0 pr-0 mt-3 text-danger">
                                                <strong>Note:
                                                    <?php echo e(SettingHelper::getSettingValueBySLug('transection_charges')); ?>%
                                                    Transaction Charges Applied on each transaction.</strong>
                                            </span>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/user/withdraw/add.blade.php ENDPATH**/ ?>