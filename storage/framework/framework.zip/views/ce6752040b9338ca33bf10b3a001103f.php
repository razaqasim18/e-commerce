<div class="row">

    <?php $__empty_1 = true; $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4 col-md-6 col-12 colstyle">
            <div class="single-product">
                <div class="product-img">
                    <a href="<?php echo e(route('product.detail', Crypt::encrypt($row->id))); ?>">
                        <img class="default-img"
                            src="<?php echo e($row->image ? asset('uploads/product') . '/' . $row->image : asset('img/products/product-1.png')); ?>"
                            alt="<?php echo e($row->product); ?>">
                        <img class="hover-img"
                            src="<?php echo e($row->image ? asset('uploads/product') . '/' . $row->image : asset('img/products/product-1.png')); ?>"
                            alt="<?php echo e($row->product); ?>">
                        
                    </a>
                    <div class="button-head">
                        <div class="product-action">
                            <a class="viewProduct" title="Quick View"
                                href="<?php echo e(route('product.detail', Crypt::encrypt($row->id))); ?>"><i
                                    class=" ti-eye"></i><span>Quick Shop</span></a>
                        </div>
                        <div class="product-action-2">
                            <a title="Add to cart" href="javascript:void(0)" id="addToCart"
                                data-productid="<?php echo e($row->id); ?>">Add to cart</a>
                        </div>
                    </div>
                </div>
                <div class="product-content">
                    <h3><a href="<?php echo e(route('product.detail', Crypt::encrypt($row->id))); ?>"><?php echo e($row->product); ?></a>
                    </h3>
                    <div class="product-price">
                        <span>PKR <?php echo e($row->price); ?></span>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-lg-12 col-md-12 col-12 colstyle">
            <div class="text-center">
                <h4>No Record Found!</h4>
            </div>
        </div>
    <?php endif; ?>
    <div class="col-lg-12 col-md-12 col-12">
        <div id="paginationLinks" style="display: flex;">
            <?php echo e($product->links()); ?>

        </div>
    </div>

</div>
<?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/include/shop.blade.php ENDPATH**/ ?>