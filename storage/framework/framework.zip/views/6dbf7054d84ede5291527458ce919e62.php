<?php $__env->startSection('title'); ?>
    User || Dasboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Pending Orders</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Inprocess Orders</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Delivered Orders</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Reject Orders</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Total Orders</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Refused Orders</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Cash back</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> Rs: 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>PSP</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> Rs: 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Last Earning</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> Rs: 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Total Earning</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> Rs: 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Cash Out Request</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="card card-primary">
                            <div class="card-header text-center" style="display:block;">
                                <h4>Gift And Rewards</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h3> 0 </h3>
                                    </div>
                                    <div class="col-6">
                                        <i class="fas fa-shopping-cart card-icon font-30 p-r-30"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/user/home.blade.php ENDPATH**/ ?>