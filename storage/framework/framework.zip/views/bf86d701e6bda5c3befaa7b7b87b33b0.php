<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/bundles/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-header">
                                <h4>Order</h4>
                                <div class="card-header-action">
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped" style="border: 2px solid #F5F5F5">
                                        <tbody>
                                            <tr>
                                                <th>
                                                    Order No.
                                                </th>
                                                <td>
                                                    <?php echo e($order->order_no); ?>

                                                </td>
                                                <th>
                                                    Order Status
                                                </th>
                                                <td>
                                                    <?php if($order->status == 0): ?>
                                                        <div class="badge badge-primary">Pending</div>
                                                    <?php elseif($order->status == 1): ?>
                                                        <div class="badge badge-info">Processing</div>
                                                    <?php elseif($order->status == 2): ?>
                                                        <div class="badge badge-success">Approved</div>
                                                    <?php else: ?>
                                                        <div class="badge badge-danger">Reject</div>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>
                                                    Order Shipping Charges
                                                </th>
                                                <td>
                                                    <?php echo e('PKR ' . $order->shippingcharges); ?>

                                                </td>
                                                <th>
                                                    Order Total Bill
                                                </th>
                                                <td>
                                                    <?php echo e('PKR ' . $order->total_bill); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>
                                                    Order Points
                                                </th>
                                                <td>
                                                    <?php echo e($order->points); ?>

                                                </td>
                                                <th>
                                                    Order Payment BY
                                                </th>
                                                <td>
                                                    <?php if($order->pament_by): ?>
                                                        <div class="badge badge-primary">Wallet</div>
                                                    <?php else: ?>
                                                        <div class="badge badge-info">Cash</div>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h4>Order Detail</h4>
                                <div class="card-header-action">
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped" style="border: 2px solid #F5F5F5">
                                        <tbody>
                                            <tr>
                                                <th>
                                                    Product
                                                </th>
                                                <th>
                                                    Quantity
                                                </th>
                                                <th>
                                                    Point
                                                </th>
                                                <th>
                                                    Price
                                                </th>
                                            </tr>
                                            <?php $__currentLoopData = $order->orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($row->product); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($row->quantity); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($row->points); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($row->price); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h4>Order Shipping Address</h4>
                                <div class="card-header-action">
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped" style="border: 2px solid #F5F5F5">
                                        <tbody>
                                            <tr>
                                                <th>
                                                    Customer Name
                                                </th>
                                                <td>
                                                    <?php echo e($order->orderShippingDetail->name); ?>

                                                </td>
                                                <th>
                                                    Customer Phone
                                                </th>
                                                <td>
                                                    <?php echo e($order->orderShippingDetail->phone); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>
                                                    Customer Email
                                                </th>
                                                <td>
                                                    <?php echo e($order->orderShippingDetail->email); ?>

                                                </td>
                                                <th>
                                                    City
                                                </th>
                                                <td>
                                                    <?php echo e($order->orderShippingDetail->city->city); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>
                                                    Street
                                                </th>
                                                <td>
                                                    <?php echo e($order->orderShippingDetail->street); ?>

                                                </td>
                                                <th>
                                                    Address
                                                </th>
                                                <td>
                                                    <?php echo e($order->orderShippingDetail->address); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th>
                                                    Shipping Address
                                                </th>
                                                <td>
                                                    <?php echo e($order->orderShippingDetail->shipping_address); ?>

                                                </td>
                                                <th>
                                                    Other Information
                                                </th>
                                                <td>
                                                    <?php echo e($order->orderShippingDetail->other); ?>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/vendor/print/pdf.blade.php ENDPATH**/ ?>