<?php $__env->startSection('title'); ?>
    Admin || Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/bundles/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Product List</h4>
                                <div class="card-header-action">
                                    <a href="<?php echo e(route('admin.product.add')); ?>" class="btn btn-primary">Add
                                        Product
                                    </a>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover" id="table-1" style="width:100%;">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Category</th>
                                                <th>Product</th>
                                                <th>Product Price</th>
                                                <th>Product Points</th>
                                                <th>Image</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1; ?>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($i++); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($row->category); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($row->product); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e('PKR ' . $row->price); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($row->points); ?>

                                                    </td>
                                                    <td>
                                                        <?php if($row->image): ?>
                                                            <img alt="image"
                                                                src="<?php echo e(asset('uploads/product') . '/' . $row->image); ?>"
                                                                class="user-img-radious-style" width="50px">
                                                        <?php else: ?>
                                                            <img alt="image"
                                                                src="<?php echo e(asset('img/products/product-1.png')); ?>"
                                                                class="user-img-radious-style" width="50px">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($row->is_active): ?>
                                                            <div class="badge badge-success">Active</div>
                                                        <?php else: ?>
                                                            <div class="badge badge-danger">Inactive</div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('admin.product.edit', $row->pid)); ?>"
                                                            class="btn btn-sm btn-primary">
                                                            <i class="far fa-edit"></i>
                                                        </a>
                                                        <button class="btn btn-sm btn-danger" id="deletePaymentMethod"
                                                            data-id="<?php echo e($row->pid); ?>">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('bundles/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/datatables.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $("#table-1").on("click", "button#deletePaymentMethod", function() {
                var id = $(this).data("id");
                swal({
                        title: 'Are you sure?',
                        text: "Once deleted, you will not be able to recover",
                        icon: 'warning',
                        buttons: true,
                        dangerMode: true,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                            var token = $("meta[name='csrf-token']").attr("content");
                            var url = '<?php echo e(url('/admin/product/delete')); ?>' + '/' + id;
                            $.ajax({
                                url: url,
                                type: 'DELETE',
                                dataType: 'json',
                                data: {
                                    "id": id,
                                    "_token": token,
                                },
                                beforeSend: function() {
                                    $(".loader").show();
                                },
                                complete: function() {
                                    $(".loader").hide();
                                },
                                success: function(response) {
                                    var typeOfResponse = response.type;
                                    var res = response.msg;
                                    if (typeOfResponse == 0) {
                                        swal('Error', res, 'error');
                                    } else if (typeOfResponse == 1) {
                                        swal({
                                                title: 'Success',
                                                text: res,
                                                icon: 'success',
                                                type: 'success',
                                                showCancelButton: false, // There won't be any cancel button
                                                showConfirmButton: true // There won't be any confirm button
                                            })
                                            .then((ok) => {
                                                if (ok) {
                                                    location.reload();
                                                }
                                            });
                                    }
                                }
                            });
                        }
                    });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/admin/product/list.blade.php ENDPATH**/ ?>