<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Slider Area -->
    <section class="hero-slider">
        <!-- Single Slider -->
        <div class="single-slider">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col-lg-9 offset-lg-3 col-12">
                        <div class="text-inner">
                            <div class="row">
                                <div class="col-lg-7 col-12">
                                    <div class="hero-text">
                                        <h1><span>UP TO 50% OFF </span>Shirt For Man</h1>
                                        <p>Maboriosam in a nesciung eget magnae <br> dapibus disting tloctio in the find
                                            it pereri <br> odiy maboriosm.</p>
                                        <div class="button">
                                            <a href="#" class="btn">Shop Now!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Single Slider -->
    </section>
    <!--/ End Slider Area -->

    <!-- Start Small Banner  -->
    <section class="small-banner section">
        <div class="container-fluid">
            <div class="row">
                <!-- Single Banner  -->
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="single-banner">
                        <img src="https://via.placeholder.com/600x370" alt="#">
                        <div class="content">
                            <p>Man's Collectons</p>
                            <h3>Summer travel <br> collection</h3>
                            <a href="#">Discover Now</a>
                        </div>
                    </div>
                </div>
                <!-- /End Single Banner  -->
                <!-- Single Banner  -->
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="single-banner">
                        <img src="https://via.placeholder.com/600x370" alt="#">
                        <div class="content">
                            <p>Bag Collectons</p>
                            <h3>Awesome Bag <br> 2020</h3>
                            <a href="#">Shop Now</a>
                        </div>
                    </div>
                </div>
                <!-- /End Single Banner  -->
                <!-- Single Banner  -->
                <div class="col-lg-4 col-12">
                    <div class="single-banner tab-height">
                        <img src="https://via.placeholder.com/600x370" alt="#">
                        <div class="content">
                            <p>Flash Sale</p>
                            <h3>Mid Season <br> Up to <span>40%</span> Off</h3>
                            <a href="#">Discover Now</a>
                        </div>
                    </div>
                </div>
                <!-- /End Single Banner  -->
            </div>
        </div>
    </section>
    <!-- End Small Banner -->


    <!-- Start Feature Popular -->
    <div class="product-area most-popular section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Feature Product</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="owl-carousel popular-slider">
                        <?php $__currentLoopData = $featureproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Start Single Product -->
                            <div class="single-product">
                                <div class="product-img">
                                    <a href="<?php echo e(route('product.detail', Crypt::encrypt($row->id))); ?>">
                                        <img class="default-img"
                                            src="<?php echo e($row->image ? asset('uploads/product') . '/' . $row->image : asset('img/products/product-1.png')); ?>"
                                            alt="<?php echo e($row->product); ?>">
                                        <img class="hover-img"
                                            src="<?php echo e($row->image ? asset('uploads/product') . '/' . $row->image : asset('img/products/product-1.png')); ?>"
                                            alt="<?php echo e($row->product); ?>">
                                        
                                    </a>
                                    <div class="button-head">
                                        <div class="product-action">
                                            <a class="viewProduct" title="Quick View"
                                                href="<?php echo e(route('product.detail', Crypt::encrypt($row->id))); ?>"><i
                                                    class=" ti-eye"></i><span>Quick Shop</span></a>
                                            
                                        </div>
                                        <div class="product-action-2">
                                            <a title="Add to cart" href="javascript:void(0)" id="addToCart"
                                                data-productid="<?php echo e($row->id); ?>">Add to cart</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h3><a
                                            href="<?php echo e(route('product.detail', Crypt::encrypt($row->id))); ?>"><?php echo e($row->product); ?></a>
                                    </h3>
                                    <div class="product-price">
                                        
                                        <span><?php echo e('PKR ' . $row->price); ?></span>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Product -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Feature Popular -->

    <!-- Start Midium Banner  -->
    <section class="midium-banner">
        <div class="container">
            <div class="row">
                <!-- Single Banner  -->
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="single-banner">
                        <img src="https://via.placeholder.com/600x370" alt="#">
                        <div class="content">
                            <p>Man's Collectons</p>
                            <h3>Man's items <br>Up to<span> 50%</span></h3>
                            <a href="#">Shop Now</a>
                        </div>
                    </div>
                </div>
                <!-- /End Single Banner  -->
                <!-- Single Banner  -->
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="single-banner">
                        <img src="https://via.placeholder.com/600x370" alt="#">
                        <div class="content">
                            <p>shoes women</p>
                            <h3>mid season <br> up to <span>70%</span></h3>
                            <a href="#" class="btn">Shop Now</a>
                        </div>
                    </div>
                </div>
                <!-- /End Single Banner  -->
            </div>
        </div>
    </section>
    <!-- End Midium Banner -->

    <!-- Start Shop Services Area -->
    <section class="shop-services section home" style="margin-top:100px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Single Service -->
                    <div class="single-service">
                        <i class="ti-rocket"></i>
                        <h4>Free shiping</h4>
                        <p>Orders over $100</p>
                    </div>
                    <!-- End Single Service -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Single Service -->
                    <div class="single-service">
                        <i class="ti-reload"></i>
                        <h4>Free Return</h4>
                        <p>Within 30 days returns</p>
                    </div>
                    <!-- End Single Service -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Single Service -->
                    <div class="single-service">
                        <i class="ti-lock"></i>
                        <h4>Sucure Payment</h4>
                        <p>100% secure payment</p>
                    </div>
                    <!-- End Single Service -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Single Service -->
                    <div class="single-service">
                        <i class="ti-tag"></i>
                        <h4>Best Peice</h4>
                        <p>Guaranteed price</p>
                    </div>
                    <!-- End Single Service -->
                </div>
            </div>
        </div>
    </section>
    <!-- End Shop Services Area -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('document').ready(function() {

            $('.viewProduct').click(function() {
                let id = $(this).data('productid');
                var url = "<?php echo e(url('/ajax/product/detail')); ?>" + "/" + id;
                $.ajax({
                    url: url,
                    method: "GET",
                    beforeSend: function() {
                        $(".preloader").show();
                    },
                    complete: function() {
                        $(".preloader").hide();
                    },
                    success: function(response) {
                        let product = response.product;
                        let media = response.productmedia;
                        <?php if(SettingHelper::getSettingValueBySLug('gst_charges')): ?>
                            var gst_charges =
                                <?php echo e(SettingHelper::getSettingValueBySLug('gst_charges')); ?> +
                                Number(0);
                        <?php endif; ?>
                        if (product) {
                            var contentoutput = '';
                            contentoutput +=
                                '<div>';
                            contentoutput += '<h2>' + product.product + '</h2>';
                            contentoutput += '<h3>Price: PKR ' + product.price + '</h3>';
                            if (gst_charges) {
                                contentoutput += '<h3>PRICE With GST: PKR ' + Math.ceil(Number(
                                            product
                                            .price) +
                                        Number(product.price / Number(gst_charges))) +
                                    '</h3>';
                            }
                            contentoutput += '<div class="quickview-peragraph">';
                            contentoutput += '<p>' + product.description + '</p>';
                            contentoutput += '</div><br /><div class="quantity">';
                            contentoutput +=
                                '<div class="input-group"><div class="button minus" >';
                            contentoutput +=
                                '<button type="button" id="buttonminus" class="btn btn-primary btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">';
                            contentoutput += '<i class="ti-minus"></i></button></div>';
                            contentoutput +=
                                '<input type="text" id="productquantity" name="quant[1]" class="input-number" data-min="1" data-max="1000" value="1">';
                            contentoutput += '<div class="button plus" >';
                            contentoutput +=
                                '<button type="button" id="buttonplus" class="btn btn-primary btn-number" data-type="plus" data-field="quant[1]">';
                            contentoutput +=
                                '<i class="ti-plus"></i></button></div></div></div>';
                            contentoutput += '<div class="add-to-cart">';
                            contentoutput +=
                                '<a href="javascript:void(0)" id="addToCart" class="btn">Add to cart</a>';
                            contentoutput += '</div></div>';
                            $("#productContent").html(contentoutput);
                            $("#exampleModal").modal("show");
                        } else {
                            console.log("error")
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel\e-commerce\resources\views/welcome.blade.php ENDPATH**/ ?>