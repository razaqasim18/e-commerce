<?php

namespace App\Http\Controllers\Admin;

use App\Helpers\CustomHelper;
use App\Http\Controllers\Controller;
use App\Models\EpinRequest;
use App\Notifications\EpinRequestApprovedNotification;
use App\Notifications\EpinRequestFailedNotification;
use Illuminate\Http\Request;

class EpinController extends Controller
{
    
}
