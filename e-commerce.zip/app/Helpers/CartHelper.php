<?php

namespace App\Helpers;

class CartHelper
{
    public static function cartCountitem()
    {

    }
}
