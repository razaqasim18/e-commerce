@extends('layouts.eshop')
@section('style')
@endsection

@section('content')
    <!-- Breadcrumbs -->
    <div class="breadcrumbs bgImage d-flex justify-content-center align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-flex justify-content-center align-items-center">
                    <a href="#">About us</a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->

    <!-- Start About -->
    <section id="about-us" class="sectionOne">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h4 class="about_heading">What we do?</h4>
                    <p class="about_us_para">
                        ABF( Attire beauty fragrance) is directly selling Cosmetics company recently launched in
                        Pakistan.ABF sells product of personal care & cosmetic directly to consumers through a network of
                        independent seller's. ABF( Attire beauty fragrance) launched organic products / non chemical
                        products for skin & hair issue and also added another Cosmetics products. through this platform many
                        people can start their business easily online. our platform is especially formed for females. they
                        easily can manage their business with their house chores.
                        They also can make network and earn bonus in every month..
                        All products Quality have 100% results.people can easily earn through this platform & get 20%
                        discount & profit immediately with sign in/Registation.</p>
                    </p>
                    <p>
                        We have enabled people from all over Pakistan to celebrate their personal beauty fulfil their
                        dreams.
                        We offer high quality , organic.trendy products to beauty lovers to became a part of global beauty
                        community.
                    </p>
                    <p>
                        As a pakistan beauty brand when you look & feel good you have apportunity to reach your full
                        potential and together and with supportive global community anything is possible.

                    </p>
                    <p>
                        With us you can make money from day by day build a business to travel the world together with us.
                        So, come & join with us global beauty community of like- minded beauty lovers.
                    </p>
                    <p><b>Management Director : ZEESHAN AHMED</b></p>
                </div>
                <div class="col-md-4 aboutBG"></div>
            </div>
        </div>
    </section>
    <!--/ End About -->
@endsection

@section('script')
@endsection
